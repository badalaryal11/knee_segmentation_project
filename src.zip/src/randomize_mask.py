import numpy as np
import SimpleITK as sitk

def generate_randomized_mask(original, expanded, randomness=0.5, seed=None):
    """
    Generate a randomized mask lying between original and expanded.
    randomness: [0, 1] fraction between original (0) and expanded (1)
    """
    if seed is not None:
        np.random.seed(seed)

    orig_array = sitk.GetArrayFromImage(original)
    exp_array = sitk.GetArrayFromImage(expanded)

    random_mask = np.zeros_like(orig_array)

    between = (exp_array - orig_array) > 0
    random_voxels = np.random.rand(*orig_array.shape) < randomness

    random_mask = np.where(orig_array == 1, 1, 0)
    random_mask += ((between & random_voxels).astype(np.uint8))

    randomized_sitk = sitk.GetImageFromArray(random_mask)
    randomized_sitk.CopyInformation(original)
    return randomized_sitk
