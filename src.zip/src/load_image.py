import SimpleITK as sitk

def load_nifti_image(file_path):
    image = sitk.ReadImage(file_path)
    array = sitk.GetArrayFromImage(image)
    spacing = image.GetSpacing()
    return image, array, spacing
