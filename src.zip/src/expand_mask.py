import SimpleITK as sitk

def expand_mask(mask, expansion_mm, spacing):
    """
    Expands a binary mask outward by 'expansion_mm' using morphological dilation.
    """
    radius_voxels = [int(round(expansion_mm / s)) for s in spacing]
    ball = sitk.BinaryBallStructuringElement(radius_voxels[0])  # approximate with isotropic kernel
    dilated = sitk.BinaryDilate(mask, radius_voxels[0], ball)
    return dilated
