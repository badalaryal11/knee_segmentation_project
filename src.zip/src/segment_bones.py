import SimpleITK as sitk
import numpy as np

def basic_bone_segmentation(image, lower_threshold=300):
    """
    Simple threshold-based segmentation for bones.
    """
    segmented = sitk.BinaryThreshold(image, lowerThreshold=lower_threshold, upperThreshold=3000, insideValue=1, outsideValue=0)
    return segmented
