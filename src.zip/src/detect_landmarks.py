import numpy as np
import SimpleITK as sitk

def find_lowest_medial_lateral(mask, spacing):
    """
    Finds lowest medial and lateral tibial points from binary mask.
    Assumes Z is up-down, Y is medial-lateral.
    """
    arr = sitk.GetArrayFromImage(mask)
    coords = np.argwhere(arr == 1)

    if coords.shape[0] == 0:
        return None, None

    physical_coords = coords[:, [2, 1, 0]] * spacing[::-1]  # convert to x, y, z in mm

    z_min = np.min(physical_coords[:, 2])
    bottom_points = physical_coords[physical_coords[:, 2] <= z_min + 1.0]  # tolerance for lowest points

    medial = bottom_points[np.argmin(bottom_points[:, 1])]
    lateral = bottom_points[np.argmax(bottom_points[:, 1])]

    return medial.tolist(), lateral.tolist()

def save_landmarks(medial, lateral, output_path):
    with open(output_path, 'w') as f:
        f.write(f"Medial: {medial}\n")
        f.write(f"Lateral: {lateral}\n")
